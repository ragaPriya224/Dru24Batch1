package drubatchTwentyFour.one.unitTestingDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnitTestingDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnitTestingDemoApplication.class, args);
	}

}

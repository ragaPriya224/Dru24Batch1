package demo.practice.configurationsDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigurationsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigurationsDemoApplication.class, args);
	}

}
